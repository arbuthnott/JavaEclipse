package NoComments;

public class Launcher {

	public static void main(String[] args) {
		SeatPlanner myPlanner = new SeatPlanner();
		myPlanner.start(4,4);
	}
	
}
