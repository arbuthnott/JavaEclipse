There are 4 classes:

Flight - holds 2D array as a property.  Has 1 method "getMatch" that does some of the logical work.

Launcher - Launches the SeatPlanner application.

Passenger - simple container for names with seat numbers and preferences.

SeatPlanner - the main application class.


Versions with no comments is in a package called "NoComments" with the same class names.

The SAAD portion is in the visio file.